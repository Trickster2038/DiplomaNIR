#ifndef TIMERS_H
#define TIMERS_H

void timer0_init();
void timer1_init();

#endif
