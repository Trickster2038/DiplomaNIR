#ifndef KEYBOARD_H
#define KEYBOARD_H

char keyboard_get_state();

#endif
