#ifndef BUZZER_H
#define BUZZER_H

void buzzer_beep(int time_amount_ms);

#endif
