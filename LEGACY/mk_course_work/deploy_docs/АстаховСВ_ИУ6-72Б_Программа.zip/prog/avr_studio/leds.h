#ifndef LEDS_H
#define LEDS_H

char leds_random_line();
void leds_move_column();
void leds_update();
void leds_off();

#endif
